﻿using CourseProject.Querys;
using CourseProject.View.ReportView;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseProject.ViewModel.ReportViewModel
{
    public class VmAvgSubscription 
    {
        //объкт для запросов
        private readonly Query _query;
        //Средний срок подписки по каждому изданию
        public ObservableCollection<object> AvgSubscriptionColl { get; set; }

        //конструктор по умолчанию
        public VmAvgSubscription()
        {
            //создание коллекции
            AvgSubscriptionColl = new ObservableCollection<object>();

            //создаем объект
            _query = new Query();
        }
        //обработка команды
        //Средний срок подписки по каждому изданию"
        public void AvgSubscription()
        {
            //создать окно
            AvgSubscription view = new AvgSubscription(this);
            //чистим коллекцию
            AvgSubscriptionColl.Clear();
            //запрос к базе данных
            var temp = _query.AvgSubscription();

            //записываем в коллекцию
            foreach (var item in temp)
                AvgSubscriptionColl.Add(item);

            view.Show();

        } // AvgSubscription

    }//VmAvgSubscription
}
