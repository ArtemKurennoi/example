﻿using CourseProject.Querys;
using CourseProject.View.ReportView;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseProject.ViewModel.ReportViewModel
{
    //данные о количестве?
    public class VmDeliveryReport 
    {
        //объкт для запросов
        private readonly Query _query;
        //отчет о доставки
        public ObservableCollection<object> DeliveryReportColl { get; set; }
        //свойства для отчета
        //количество районов
        public int CountDistricts { get; set; }
        //количество почтальонов
        public int CountPostmen { get; set; }
        //количество уникальных публикаций
        public int CountDistinctPubl { get; set; }


        //конструктор по умолчанию
        public VmDeliveryReport()
        {
            //создание коллекции
            DeliveryReportColl = new ObservableCollection<object>();

            //создаем объект
            _query = new Query();

            //в отчет
            ReReadData();
        }
        //запрос для данных
        private void ReReadData()
        {
            //в отчет
            CountPostmen = _query.CountPostmen();
            CountDistricts = _query.CountDistricts();
            CountDistinctPubl = _query.CountDistinctPubl();
        }//ReReadData

        //обработка команды
        //Отчет о доставке
        public void DeliveryReport()
        {
            //перечитать данные
            ReReadData();
            //сколько почтальонов работает в почтовом отделении, сколько 
            // всего участков оно обслуживает, сколько различных изданий доставляет подписчикам.

            //создать окно
            DeliveryReport view = new DeliveryReport(this);
            //назначим на кнопку закрытие окна

            //чистим коллекцию
            DeliveryReportColl.Clear();
            //запрос к базе данных
            var temp = _query.DeliveryReport();

            //записываем в коллекцию
            foreach (var item in temp)
                DeliveryReportColl.Add(item);

            view.Show();

        }//DeliveryReport


    }
}
