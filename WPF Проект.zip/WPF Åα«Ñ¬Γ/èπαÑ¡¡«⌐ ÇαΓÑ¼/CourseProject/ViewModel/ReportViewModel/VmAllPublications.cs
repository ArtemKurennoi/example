﻿using CourseProject.Querys;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using CourseProject.View.ReportView;

namespace CourseProject.ViewModel.ReportViewModel
{
    public class VmAllPublications 
    {
        //объкт для запросов
        private readonly Query _query;
        //отчет все публикации
        public ObservableCollection<object> AllPublicationsColl { get; set; }

        //конструктор по умолчанию
        public VmAllPublications()
        {
            //создание коллекции
            AllPublicationsColl = new ObservableCollection<object>();

            //создаем объект
            _query = new Query();
        }

        //обработка команды
        //Все издания
        public void ViewPublications()
        {
            //создать окно
            AllPublications view = new AllPublications(this);
            //чистим коллекцию
            AllPublicationsColl.Clear();
            //запрос к базе данных
            var temp = _query.AllPublications();

            //записываем в коллекцию
            foreach (var item in temp)
                AllPublicationsColl.Add(item);

            view.Show();
        } // ViewPublications

    }//VmAllPublications
}
