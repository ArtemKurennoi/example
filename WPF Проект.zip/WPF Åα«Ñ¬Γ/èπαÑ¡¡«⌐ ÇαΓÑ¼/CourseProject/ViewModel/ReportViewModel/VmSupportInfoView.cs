﻿using CourseProject.Querys;
using CourseProject.View.ReportView;
using System;
using System.Collections.ObjectModel;

namespace CourseProject.ViewModel.ReportViewModel
{
    //данные о количестве?
    public class VmSupportInfoView 
    {
        //объкт для запросов
        private readonly Query _query;
        //отчет все публикации
        public ObservableCollection<object> AllPublicationsColl { get; set; }
        //свойства для отчета
        public int CountSubscribers { get; set; }
        public int CountPostmen { get; set; }
        public int CountNewspapers { get; set; }
        public int CountMagazines { get; set; }

        //конструктор по умолчанию
        public VmSupportInfoView()
        {
            //создание коллекции
            AllPublicationsColl = new ObservableCollection<object>();

            //создаем объект
            _query = new Query();
            //данные
            ReReadData();
        }

        public void ViewSupportInfo()
        {
            //перечитать данные
            ReReadData();
            //создать окно
            SupportInfoView view = new SupportInfoView(this);
            //назначим на кнопку закрытие окна
            view.btnSupInfo.Command = new Command(obj => view.Close());
            //view.btnSupInfo.Click += new RoutedEventHandler((a,b)=> { view.Close(); }) ;
            //вывести
            view.Show();

        }//ViewSupportInfo

        //запрос для данных
        private void ReReadData()
        {
            //в отчет
            CountSubscribers = _query.CountSubscribers();
            CountPostmen = _query.CountPostmen();
            CountNewspapers = _query.CountNewspapers();
            CountMagazines = _query.CountMagazines();
        }//ReReadData
    }
}
