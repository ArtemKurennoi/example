﻿using CourseProject.Model;
using CourseProject.Querys;
using CourseProject.View.ReportView;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace CourseProject.ViewModel.ReportViewModel
{
    //список подписчиков ?
    public class VmFindNewspapers
    {
        //объкт для запросов
        private readonly Query _query;
        //Поиск газет
        public ObservableCollection<object> NewspapersColl { get; set; }

        //конструктор по умолчанию
        public VmFindNewspapers()
        {
            //создание коллекции
            NewspapersColl = new ObservableCollection<object>();

            //создаем объект
            _query = new Query();
        }

        public void FindNewspapers()
        {
            //создать окно
            FindNewspapers view = new FindNewspapers(this);

            //изменение выбранного элемента
            view.cbxAllSubscribers.SelectionChanged += new SelectionChangedEventHandler((a, b) =>
            { ViewNewspapers(view.cbxAllSubscribers.SelectedItem); });
            //вывод
            view.Show();
        } // FindNewspapers
        private void ViewNewspapers(object selectedItem)
        {
            //приводим
            var subscribers = selectedItem as Subscribers;
            //запрос для выборки
            var temp = _query.SelectNewspapers(subscribers.Id);
            //чистим коллекцию
            NewspapersColl.Clear();
            //записываем в коллекцию
            foreach (var item in temp)
                NewspapersColl.Add(item);
        }//ViewNewspapers

        //Найти газеты по подписчику" 
        //все подписчики которые подписаны на тип "газета"
        public ObservableCollection<Subscribers> AllSubscribers
        {
            get => _query.SelectSubscribers();
        }//AllSubscribers
    }
}
