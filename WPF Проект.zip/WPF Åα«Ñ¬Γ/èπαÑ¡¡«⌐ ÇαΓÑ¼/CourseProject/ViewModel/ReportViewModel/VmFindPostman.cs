﻿using CourseProject.Model;
using CourseProject.Querys;
using CourseProject.View.ReportView;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace CourseProject.ViewModel.ReportViewModel
{
    //список почтальонов ?
    public class VmFindPostman 
    {
        //объкт для запросов
        private readonly Query _query;
        //Поиск почтальона
        public ObservableCollection<object> PostmenColl { get; set; }

        //конструктор по умолчанию
        public VmFindPostman()
        {
            //создание коллекции
            PostmenColl = new ObservableCollection<object>();
            //создаем объект
            _query = new Query();
        }
        //вызывает команда
        public void FindPostman()
        {
            //создать окно
            FindPostman view = new FindPostman(this);

            //изменение выбранного элемента
            view.cbxAllAddresses.SelectionChanged += new SelectionChangedEventHandler((a, b) =>
            { ViewPostman(view.cbxAllAddresses.SelectedItem); });
            //вывод
            view.Show();
        } // FindPostman
        //поиск почтальона по адрессу
        private void ViewPostman(object selectedItem)
        {
            //приводим
            var address = selectedItem as Addresses;
            //запрос для выборки
            var temp = _query.SelectPostmen(address.DistrictId);
            //чистим коллекцию
            PostmenColl.Clear();
            //записываем в коллекцию
            foreach (var item in temp)
                PostmenColl.Add(item);

        }//ViewPostman

        //Найти почтальона по адресу" 
        //все адресса
        public ObservableCollection<Addresses> AllAddresses
        {
            get => _query.SelectAddresses();
        }//AllAddresses
    }
}
