﻿using CourseProject.Querys;
using CourseProject.View.ReportView;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseProject.ViewModel.ReportViewModel
{
    public class VmDistrictMaxNum 
    {
        //объкт для запросов
        private readonly Query _query;
        //районы с максимальным количеством
        public ObservableCollection<object> DistrictsMaxNumColl { get; set; }

        //конструктор по умолчанию
        public VmDistrictMaxNum()
        {
            //создание коллекции
            DistrictsMaxNumColl = new ObservableCollection<object>();

            //создаем объект
            _query = new Query();
        }
        public void DistrictMaxNumExe()
        {
            //запрос для выборки
            var temp = _query.DistrictMaxNum();
            //чистим коллекцию
            DistrictsMaxNumColl.Clear();
            //записываем в коллекцию
            foreach (var item in temp)
                DistrictsMaxNumColl.Add(item);

            //создать окно
            DistrictMaxNum view = new DistrictMaxNum(this);
            //назначим на кнопку закрытие окна
            //вывести
            view.Show();

        } // DistrictMaxNumExe
    }
}
