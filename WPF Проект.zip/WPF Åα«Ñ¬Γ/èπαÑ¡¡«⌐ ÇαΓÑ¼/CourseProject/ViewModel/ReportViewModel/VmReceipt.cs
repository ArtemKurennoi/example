﻿using CourseProject.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourseProject.Querys;
using CourseProject.View.ReportView;

namespace CourseProject.ViewModel.ReportViewModel
{
    public class VmReceipt
    {
        //объкт для запросов
        private readonly Query _query;
        //конструктор по умолчанию
        public VmReceipt(Subscriptions newSubscription)
        {
            //создаем объект
            _query = new Query();
            //создали окно
            Receipt view = new Receipt(this);
            //заполняем поля
            FillReceipt(view,newSubscription);
            //закрыть окно
            view.btnOk.Command = new Command(obj => view.Close());
            //вывести
            view.Show();
        }

        //заполняем данные квитанции
        private void FillReceipt(Receipt view, Subscriptions newSubscription)
        {
            //получить данные нового подписчика\
            Subscriptions selectSubscription =_query.SelectSubscription(newSubscription);
            view.txbPublication.Text = $"{selectSubscription.Publication.PublicationIndex} {selectSubscription.Publication.Title}";
            view.txbSubscriber.Text = $"{selectSubscription.Subscriber.Surname} {selectSubscription.Subscriber.Name} {selectSubscription.Subscriber.Patronymic}";
            view.txbDuration.Text = $"{selectSubscription.Duration}";
            view.txbStart.Text = selectSubscription.StartDate.ToString("dd/MM/yyyy");
            //общая стоисомть
            view.txbTotalCost.Text = $"{selectSubscription.Publication.Price * selectSubscription.Duration}";
        }//FillReceipt
    }
}
