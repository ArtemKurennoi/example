﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourseProject.Model;
using CourseProject.View;
using CourseProject.Querys;
using CourseProject.Context;
using CourseProject.View.ReportView;
using System.Collections.ObjectModel;
using System.Windows.Controls;
using CourseProject.ViewModel.EditViewModel;
using CourseProject.ViewModel.ReportViewModel;

namespace CourseProject.ViewModel
{
    // команд, вью модели
    public partial class PostOffice
    {
        #region Вкладка отчеты
        //вью модель
        readonly VmSupportInfoView vmSupportInfoView = new VmSupportInfoView();
        //Количество подписчиков, почтальонов, газет, журналов" 
        private Command supportInfoCommand;
        public Command SupportInfoCommand =>
            supportInfoCommand ??
            (supportInfoCommand = new Command(obj => vmSupportInfoView.ViewSupportInfo()));

        //вью модель
        readonly VmDeliveryReport vmDeliveryReport = new VmDeliveryReport();
        //Отчет о доставке" 
        //DeliveryReport
        private Command deliveryReportCommand;
        public Command DeliveryReportCommand =>
            deliveryReportCommand ??
            (deliveryReportCommand = new Command(obj => vmDeliveryReport.DeliveryReport()));
        #endregion

        #region Вкладка Информация
        //вью модель для окна все публикации
        readonly VmAllPublications vmAllPublications = new VmAllPublications();

        //команда Все издания
        private Command allPublicationsCommand;
        public Command AllPublicationsCommand =>
            allPublicationsCommand ??
            (allPublicationsCommand = new Command(obj => vmAllPublications.ViewPublications()));

        //вью модель
        readonly VmFindPostman vmFindPostman = new VmFindPostman();

        //команда Найти почтальона
        private Command findPostmanCommand;
        public Command FindPostmanCommand =>
            findPostmanCommand ??
            (findPostmanCommand = new Command(obj => vmFindPostman.FindPostman()));

        //вью модель
        readonly VmFindNewspapers vmFindNewspapers = new VmFindNewspapers();

        //команда найти газеты
        private Command findNewspapersCommand;
        public Command FindNewspapersCommand =>
            findNewspapersCommand ??
            (findNewspapersCommand = new Command(obj => vmFindNewspapers.FindNewspapers()));

        //вью модель
        readonly VmDistrictMaxNum vmDistrictMaxNum = new VmDistrictMaxNum();
        //Участок с максимальные количестом экземпляров или несколько
        //команда
        private Command districtMaxNumCommand;
        public Command DistrictMaxNumCommand =>
            districtMaxNumCommand ??
            (districtMaxNumCommand = new Command(obj => vmDistrictMaxNum.DistrictMaxNumExe()));

        //вью модель для выполнения команды
        readonly VmAvgSubscription vmAvgSubscription = new VmAvgSubscription();
        //Средний срок подписки по каждому изданию" 
        //команда 
        private Command avgSubscriptionCommand;
        public Command AvgSubscriptionCommand =>
            avgSubscriptionCommand ??
            (avgSubscriptionCommand = new Command(obj => vmAvgSubscription.AvgSubscription()));
        #endregion


        #region Добавление/удаление почтальона, назначение на участок
        //вью модель
        readonly VmAddPostman vmAddPostman = new VmAddPostman();
        //вью модель
        //команда добавление почтальона
        private Command addPostmanCommand;

        public Command AddPostmanCommand =>
            addPostmanCommand ??
            (addPostmanCommand = new Command(obj => vmAddPostman.AddPostman(this)));

        //вью модель
        readonly VmAssignPostman vmAssignDistrict = new VmAssignPostman();
        //вью модель
        //команда назначение почтальона на участок
        private Command assignAssignPostman;

        public Command AssignAssignPostman =>
            assignAssignPostman ??
            (assignAssignPostman = new Command(obj => vmAssignDistrict.AssignPostman(this)));


        //вью модель
        readonly VmRemovePostman vmRemovePostman = new VmRemovePostman();
        //команда удаление почтальона
        private Command removePostmanCommand;
        public Command RemovePostmanCommand =>
            removePostmanCommand ??
            (removePostmanCommand = new Command(obj => vmRemovePostman.RemovePostman(this)));
        #endregion

        #region Добавление /удаление публикации

        //вью модель
        readonly VmRemovePublication vmRemovePublication = new VmRemovePublication();
        //команда удаление публикации
        private Command removePublicationCommand;
        public Command RemovePublicationCommand =>
            removePublicationCommand ??
            (removePublicationCommand = new Command(obj => vmRemovePublication.RemovePublication(this)));

        //вью модель
        readonly VmAddPublication vmAddPublication = new VmAddPublication();
        //команда добавление публикации
        private Command addPublicationCommand;

        public Command AddPublicationCommand =>
            addPublicationCommand ??
            (addPublicationCommand = new Command(obj => vmAddPublication.AddPublication(this)));

        #endregion

        #region Оформление подписки
        //вью модель
        readonly VmNewSubscribe vmNewSubscribe = new VmNewSubscribe();
        //команда добавление публикации
        private Command newSubscribeCommand;

        public Command NewSubscribeCommand =>
            newSubscribeCommand ??
            (newSubscribeCommand = new Command(obj => vmNewSubscribe.NewSubscribe(this)));
        #endregion

        #region Добавление / удаление подписчика
        //вью модель
        readonly VmRemoveSubscriber vmRemoveSubscriber = new VmRemoveSubscriber();
        //команда удаление публикации
        private Command removeSubscriberCommand;
        public Command RemoveSubscriberCommand =>
            removeSubscriberCommand ??
            (removeSubscriberCommand = new Command(obj => vmRemoveSubscriber.RemoveSubscriber(this)));

        //вью модель
        readonly VmAddSubscriber vmAddSubscriber = new VmAddSubscriber();
        //команда удаление публикации
        private Command addSubscriberCommand;
        public Command AddSubscriberCommand =>
            addSubscriberCommand ??
            (addSubscriberCommand = new Command(obj => vmAddSubscriber.AddSubscriber(this)));
        #endregion
    }//PostOffice
}

