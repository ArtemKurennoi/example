﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using CourseProject.Model;
using CourseProject.Querys;
using CourseProject.View.EditView;

namespace CourseProject.ViewModel.EditViewModel
{
    public class VmRemovePublication
    {
        //объкт для запросов
        private readonly Query _query;
        //объект главной вью модели
        private PostOffice _postOffice;
        //все публикации
        public ObservableCollection<object> AllPublications { get; set; }

        //конструктор по умолчанию
        public VmRemovePublication()
        {
            //создание коллекции
            AllPublications = new ObservableCollection<object>();

            //создаем объект
            _query = new Query();
        }

        //удаление публикации
        public void RemovePublication(PostOffice postOffice)
        {
            //запомнить ссылку
            _postOffice = postOffice;
            //чистим коллекцию
            AllPublications.Clear();

            //запрос к базе данных
            var temp = _query.AllPublications();

            //записываем в коллекцию
            foreach (var item in temp)
                AllPublications.Add(item);

            //создать окно
            RemovePublication view = new RemovePublication(this);

            //вывести
            view.Show();
            //выбрать нужного почтальона
            //при нажатии на кнопку ок запускаем событие 
            view.btnOk.Command = new Command(obj =>
            {
                //если последний почтальон
                if (AllPublications.Count == 1)
                {
                    MessageBox.Show("Удаление последней публикации невозможно!");
                    return;
                }//if

                if (view.dgPublications.SelectedItem == null)
                    MessageBox.Show("Выберите публикацию");
                else
                {
                    Remove(view.dgPublications.SelectedItem as Publications);
                    view.Close();
                }
            });
            //назначим на кнопку закрытие окна
            view.btnCancel.Command = new Command(obj => view.Close());

        }//RemovePublication

        private void Remove(Publications publication)
        {
            //поставить отметку о неактуальности
            _query.RemovePublication(publication);
            //изменить значение свойства, для срабатывания OnPropertyChanged
            //пересчитать публикации
            _postOffice.CountNewspapers = _query.CountNewspapers();
            _postOffice.CountMagazines = _query.CountMagazines();
        }//Remove
    }
}
