﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using CourseProject.Model;
using CourseProject.Querys;
using CourseProject.View.EditView;
using CourseProject.View.ReportView;
using CourseProject.ViewModel.ReportViewModel;

namespace CourseProject.ViewModel.EditViewModel
{
    public class VmNewSubscribe
    {
        //объкт для запросов
        private readonly Query _query;
        //объект главной вью модели
        private PostOffice _postOffice;
        //все типы публикаций
        public ObservableCollection<object> AllPublications { get; set; }
        public ObservableCollection<object> AllSubscribers { get; set; }
        //новая подписка
        private Subscriptions _newSubscription;
        //конструктор по умолчанию
        public VmNewSubscribe()
        {
            //создание коллекции
            AllPublications = new ObservableCollection<object>();
            AllSubscribers = new ObservableCollection<object>();
            //создаем объект
            _query = new Query();
        }
        public void NewSubscribe(PostOffice postOffice)
        {
            //запомнить ссылку
            _postOffice = postOffice;
            //заполняем комбобоксы
            FillComboBoxs();
            //создать окно
            NewSubscribe view = new NewSubscribe(this);
            //вывести
            view.Show();

            //обработка ОК
            view.btnOk.Command = new Command(obj =>
            {
                //view.dpStart
                if (!EmptyValues(view.txbDuration.Text, view.cbxPublications.SelectedItem, view.cbxSubscribers.SelectedItem,view.dpStart))
                    MessageBox.Show("Данные не заполнены");
                else
                {
                    Subscribe(view.txbDuration.Text, view.cbxPublications.SelectedItem, view.cbxSubscribers.SelectedItem, view.dpStart);
                    //квитанция
                    VmReceipt receipt=new VmReceipt(_newSubscription);
                    view.Close();
                }
            });
            //назначим на кнопку закрытие окна
            view.btnCancel.Command = new Command(obj => view.Close());

        }//NewSubscribe

        //заполнить комбобоксы для просмотра
        private void FillComboBoxs()
        {
            //чистим коллекцию
            AllPublications.Clear();
            AllSubscribers.Clear();

            //запрос к базе данных
            var tempPubl = _query.AllPublications();

            //записываем в коллекцию
            foreach (var item in tempPubl)
                AllPublications.Add(item);

            //запрос к базе данных
            var tempSubs = _query.AllSubscribers();

            //записываем в коллекцию
            foreach (var item in tempSubs)
                AllSubscribers.Add(item);
        }//FillComboBox

        //проверка на пустое значение
        private bool EmptyValues(string duration,  object selectedPubl, object selectedSubs,DatePicker dpStart) =>
           duration.Length > 0  && selectedPubl != null && selectedSubs != null && dpStart.SelectedDate != null;

        //добавление
        private void Subscribe(string duration, object selectedPubl, object selectedSubs, DatePicker dpStart)
        {
            //приводим
            var publ = selectedPubl as Publications;
            var subs = selectedSubs as Subscribers;

            //создали
            _newSubscription = new Subscriptions
            {
                PublicationId = publ.Id,
                SubscriberId = subs.Id,
                Duration = int.TryParse(duration, out int res) ? res : 0,
                //подписка с текущего времени
                StartDate = dpStart.SelectedDate.Value
            };

            if (_newSubscription.Duration == 0)
                MessageBox.Show("Не корректный ввод в поле \"продолжительность подписки\"");
            else
            {
                //добавить в таблицу подписчиков
                _query.AddSubscription(_newSubscription);
                //изменить значение свойства, для срабатывания OnPropertyChanged
                //пересчитать почтальонов
                _postOffice.CountSubscribers = _query.CountSubscribers();
                //пересмотреть вывод
                _postOffice.OperatorCollectionChanges();
            }//if-else

        }//Subscribe
    }
}
