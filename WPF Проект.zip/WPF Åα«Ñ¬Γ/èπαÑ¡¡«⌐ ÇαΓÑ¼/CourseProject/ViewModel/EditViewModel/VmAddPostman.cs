﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using CourseProject.Model;
using CourseProject.Querys;
using CourseProject.View.EditView;

namespace CourseProject.ViewModel.EditViewModel
{
    public class VmAddPostman
    {
        //объкт для запросов
        private readonly Query _query;
        //объект главной вью модели
        private PostOffice _postOffice;

        //конструктор по умолчанию
        public VmAddPostman()
        {
            //создаем объект
            _query = new Query();
        }
        public void AddPostman(PostOffice postOffice)
        {
            //запомнить ссылку
            _postOffice = postOffice;
            //создать окно
            AddPostman view = new AddPostman(this);
            //вывести
            view.Show();

            //обработка ОК
            view.btnOk.Command = new Command(obj =>
            {
                if (!EmptyValues(view.txbSurname.Text, view.txbName.Text, view.txbPatronymic.Text))
                    MessageBox.Show("Данные не заполнены");
                else
                {
                    NewPostman(view.txbSurname.Text, view.txbName.Text, view.txbPatronymic.Text);
                    view.Close();
                }
            });
            //назначим на кнопку закрытие окна
            view.btnCancel.Command = new Command(obj => view.Close());

        }//AddPostman

        //проверка на пустое значение
        private bool EmptyValues(string surname, string name, string patronymic) =>
           surname.Length > 0 && name.Length > 0 && patronymic.Length > 0;

        private void NewPostman(string surname, string name, string patronymic)
        {
            //создали
            Postmen postman = new Postmen
            {
                Relevance = true,
                Surname = surname,
                Name = name,
                Patronymic = patronymic
            };

            //проверить есть ли такой почтальон
            if (!_query.CheckPostman(postman))
            {
                _query.AddPostman(postman);
                //изменить значение свойства, для срабатывания OnPropertyChanged
                //пересчитать почтальонов
                _postOffice.CountPostmen = _query.CountPostmen();
                //пересмотреть вывод
                _postOffice.ManagerCollectionChanges();
            }
            else
                MessageBox.Show("Такой почтальон уже существует");
        }//NewPostman
    }
}
