﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using CourseProject.Model;
using CourseProject.Querys;
using CourseProject.View.EditView;

namespace CourseProject.ViewModel.EditViewModel
{
    public class VmAddPublication
    {
        //объкт для запросов
        private readonly Query _query;
        //объект главной вью модели
        private PostOffice _postOffice;
        //все типы публикаций
        public ObservableCollection<object> AllType { get; set; }

        //конструктор по умолчанию
        public VmAddPublication()
        {
            //создание коллекции
            AllType = new ObservableCollection<object>();
            //создаем объект
            _query = new Query();
        }
        public void AddPublication(PostOffice postOffice)
        {
            //запомнить ссылку
            _postOffice = postOffice;
            //заполняем комбобокс
            FillComboBox();
            //создать окно
            AddPublication view = new AddPublication(this);
            //вывести
            view.Show();

            //обработка ОК
            view.btnOk.Command = new Command(obj =>
            {
                if (!EmptyValues(view.txbTitle.Text, view.txbIndex.Text, view.txbPrice.Text,view.cbxType.SelectedItem))
                    MessageBox.Show("Данные не заполнены");
                else
                {
                    NewPublication(view.txbTitle.Text, view.txbIndex.Text, view.txbPrice.Text, view.cbxType.SelectedItem);
                    view.Close();
                }
            });
            //назначим на кнопку закрытие окна
            view.btnCancel.Command = new Command(obj => view.Close());

        }//AddPostman

        private void FillComboBox()
        {
            //чистим коллекцию
            AllType.Clear();

            //запрос к базе данных
            var tempType = _query.AllType();

            //записываем в коллекцию
            foreach (var item in tempType)
                AllType.Add(item);
        }//FillComboBox

        //проверка на пустое значение
        private bool EmptyValues(string title, string index, string price, object selectedItem) =>
           title.Length > 0 && index.Length > 0 && price.Length > 0 && selectedItem != null;

        private void NewPublication(string title, string index, string price, object selectedItem)
        {
            //приводим
            var type = selectedItem as PublicationTypes;
            //создали
            Publications publication = new Publications
            {
                Relevance = true,
                Title = title,
                PublicationIndex = index,
                Price = int.TryParse(price, out int res) ? res : 0,
                PublicationTypeId = type.Id
            };
            if (publication.Price == 0)
                MessageBox.Show("Не корректный ввод в поле \"Цена\"");
            else
            {
                //проверить есть ли такая публикация
                if (!_query.CheckPublication(publication))
                {
                    _query.AddPublication(publication);
                    //изменить значение свойства, для срабатывания OnPropertyChanged
                    //пересчитать публикации
                    _postOffice.CountNewspapers = _query.CountNewspapers();
                    _postOffice.CountMagazines = _query.CountMagazines();
                }
                else
                    MessageBox.Show("Такая публикация уже существует");
            }//if-else
        }//NewPublication
    }
}
