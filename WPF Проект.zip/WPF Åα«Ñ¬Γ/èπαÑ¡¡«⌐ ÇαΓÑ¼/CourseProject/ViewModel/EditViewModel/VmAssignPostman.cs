﻿using CourseProject.Model;
using CourseProject.Querys;
using CourseProject.View.EditView;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace CourseProject.ViewModel.EditViewModel
{
    public class VmAssignPostman
    {
        //объкт для запросов
        private readonly Query _query;
        //объект главной вью модели
        private PostOffice _postOffice;
        //все почтальоны
        public ObservableCollection<object> AllPostmen { get; set; }
        //все участки
        public ObservableCollection<object> AllDistricts { get; set; }

        //конструктор по умолчанию
        public VmAssignPostman()
        {
            //создание коллекции
            AllPostmen = new ObservableCollection<object>();
            AllDistricts = new ObservableCollection<object>();

            //создаем объект
            _query = new Query();
        }

        //заполнение комбобоксов
        private void FillComboBoxs()
        {
            //чистим коллекцию
            AllPostmen.Clear();
            AllDistricts.Clear();

            //запрос к базе данных
            var tempPostman = _query.AllPostmen();

            //записываем в коллекцию
            foreach (var item in tempPostman)
                AllPostmen.Add(item);

            //запрос к базе данных
            var tempDistricts = _query.AllDistricts();

            //записываем в коллекцию
            foreach (var item in tempDistricts)
                AllDistricts.Add(item);
        }//FillComboBoxs

        //выполнение команды замена
        public void AssignPostman(PostOffice postOffice)
        {
            //запомнить ссылку
            _postOffice = postOffice;
            //заполняем комбобоксы
            FillComboBoxs();
            //создать окно
            AssignPostman view = new AssignPostman(this);
            //район
            Districts districts = null;
            //новый почтальон
            Postmen newPostman=null;
            //вывести
            view.Show();

            //обработчики смены индекса
            view.cbxAllDistricts.SelectionChanged += new SelectionChangedEventHandler((a, b) =>
            {
                //если не выбран элемент
                if (view.cbxAllDistricts.SelectedItem == null)
                    return;
                districts = SelectDistrict(view.cbxAllDistricts.SelectedItem);
                view.txbOldPostman.Text = $"ФИО: {districts.Postmen.Surname} {districts.Postmen.Name} {districts.Postmen.Patronymic}";
            });

            view.cbxAllPostmen.SelectionChanged += new SelectionChangedEventHandler((a, b) =>
            {
                //если не выбран элемент
                if (view.cbxAllPostmen.SelectedItem == null)
                    return;
                newPostman = SelectPostman(view.cbxAllPostmen.SelectedItem);
                view.txbNewPostman.Text = $"ФИО: {newPostman.Surname} {newPostman.Name} {newPostman.Patronymic}";
            });
            //выбрать нужного почтальона
            //при нажатии на кнопку ок запускаем событие 
            view.btnOk.Command = new Command(obj =>
            {
                //заменить в выбранном районе почтальона на выбранного почтальона!
                if (newPostman == null)
                    MessageBox.Show("Выберите почтальона");
                else
                {
                    //передали участок на котором поменять и нового почтальона
                    _query.ChangePostman(districts,newPostman);
                    //пересмотреть вывод
                    _postOffice.ManagerCollectionChanges();
                    view.Close();
                }
            });
            //назначим на кнопку закрытие окна
            view.btnCancel.Command = new Command(obj => view.Close());
        }//AssignPostman

        //выбор
        private Postmen SelectPostman(object selectedItem)
        {
            //приводим
            var postman = selectedItem as Postmen;
            //запрос для выборки почтальона и возврат
            return _query.SelectPostman(postman.Id);
        }//SelectPostman

        //выбор
        private Districts SelectDistrict(object selectedItem)
        {
            //приводим
            var district= selectedItem as Districts;
            //запрос для выборки района и возврат
            return _query.SelectDistrict(district.Id);
        }//SelectDistrict

    }//VmAssignDistrict
}
