﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using CourseProject.Model;
using CourseProject.Querys;
using CourseProject.View.EditView;

namespace CourseProject.ViewModel.EditViewModel
{
    public class VmAddSubscriber
    {
        //объкт для запросов
        private readonly Query _query;
        //объект главной вью модели
        private PostOffice _postOffice;
        //все типы публикаций
        public ObservableCollection<object> AllDistricts { get; set; }

        //конструктор по умолчанию
        public VmAddSubscriber()
        {
            //создание коллекции
            AllDistricts = new ObservableCollection<object>();
            //создаем объект
            _query = new Query();
        }
        public void AddSubscriber(PostOffice postOffice)
        {
            //запомнить ссылку
            _postOffice = postOffice;
            //заполняем комбобокс
            FillComboBox();
            //создать окно
            AddSubscriber view = new AddSubscriber(this);
            //вывести
            view.Show();

            //обработка ОК
            view.btnOk.Command = new Command(obj =>
            {
                if (!EmptyValues(view.txbSurname.Text, view.txbName.Text, view.txbPatronymic.Text, 
                    view.txbStreet.Text, view.txbHouse.Text, view.txbApartment.Text, view.cbxDistrict.SelectedItem))
                    MessageBox.Show("Данные не заполнены");
                else
                {
                    NewSubscriber(view.txbSurname.Text, view.txbName.Text, view.txbPatronymic.Text, 
                        view.txbStreet.Text, view.txbHouse.Text, view.txbApartment.Text, view.cbxDistrict.SelectedItem);
                    view.Close();
                }
            });
            //назначим на кнопку закрытие окна
            view.btnCancel.Command = new Command(obj => view.Close());

        }//AddSubscriber

        private void FillComboBox()
        {
            //чистим коллекцию
            AllDistricts.Clear();

            //запрос к базе данных
            var tempType = _query.AllDistricts();

            //записываем в коллекцию
            foreach (var item in tempType)
                AllDistricts.Add(item);
        }//FillComboBox

        //проверка на пустое значение
        private bool EmptyValues(string surname, string name, string patronymic, string street, string house, string apartment, object selectedItem) =>
           surname.Length > 0 && name.Length > 0 && patronymic.Length > 0 && street.Length > 0 && house.Length > 0 && apartment.Length > 0 && selectedItem != null;

        private void NewSubscriber(string surname, string name, string patronymic, string street, string house, string apartment, object selectedItem)
        {
            //приводим
            var district = selectedItem as Districts;
            //создали
            Subscribers subscriber = new Subscribers
            {
                Relevance = true,
                Surname = surname,
                Name = name,
                Patronymic = patronymic,
                Address=new Addresses {Street=street,House=house,Apartment= int.TryParse(apartment, out int res) ? res : 0,DistrictId= district.Id },
            };
            if (subscriber.Address.Apartment == 0)
                MessageBox.Show("Не корректный ввод в поле \"Квартира\"");
            else
            {
                //проверить есть ли такой подписчик
                if (!_query.CheckSubscriber(subscriber))
                {
                    _query.AddSubscriber(subscriber);
                    //изменить значение свойства, для срабатывания OnPropertyChanged
                    //пересчитать публикации
                    _postOffice.CountSubscribers = _query.CountSubscribers();
                }
                else
                    MessageBox.Show("Такой подписчик уже существует");
            }//if-else
        }//NewSubscriber
    }
}
