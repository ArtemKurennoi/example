﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using CourseProject.Model;
using CourseProject.Querys;
using CourseProject.View.EditView;

namespace CourseProject.ViewModel.EditViewModel
{
    public class VmRemovePostman
    {
        //объкт для запросов
        private readonly Query _query;
        //объект главной вью модели
        private PostOffice _postOffice;
        //все почтальоны
        public ObservableCollection<object> AllPostmen { get; set; }

        //конструктор по умолчанию
        public VmRemovePostman()
        {
            //создание коллекции
            AllPostmen = new ObservableCollection<object>();

            //создаем объект
            _query = new Query();
        }

        public void RemovePostman(PostOffice postOffice)
        {
            //запомнить ссылку
            _postOffice = postOffice;
            //чистим коллекцию
            AllPostmen.Clear();

            //запрос к базе данных
            var temp = _query.AllPostmen();

            //записываем в коллекцию
            foreach (var item in temp)
                AllPostmen.Add(item);

            //создать окно
            RemovePostman view = new RemovePostman(this);

            //вывести
            view.Show();
            //выбрать нужного почтальона
            //при нажатии на кнопку ок запускаем событие 
            view.btnOk.Command = new Command(obj =>
            {
                //если последний почтальон
                if (AllPostmen.Count == 1)
                {
                    MessageBox.Show("Увольнение последнего почтальона невозможно!");
                    return;
                }//if

                if (view.dgPostmen.SelectedItem == null)
                    MessageBox.Show("Выберите почтальона");
                else
                {
                    DismissPostman(view.dgPostmen.SelectedItem as Postmen);
                    view.Close();
                }
            });
            //назначим на кнопку закрытие окна
            view.btnCancel.Command = new Command(obj => view.Close());

        }//RemovePostman

        private void DismissPostman(Postmen postman)
        {
            //поставить отметку о неактуальности
            _query.RemovePostman(postman);
            //проверить остается ли на участке почтальон(последнего почтальона уволить нельзя))
            //если участок остается без почтальона распределить участки по другим почтальонам(случайно?)
            if (_query.CheckDistricts(postman))
                _query.DistributionDistricts(postman);
            //изменить значение свойства, для срабатывания OnPropertyChanged
            //пересчитать почтальонов
            _postOffice.CountPostmen = _query.CountPostmen();
            //пересмотреть вывод
            _postOffice.ManagerCollectionChanges();
        }//DismissPostman
    }
}
