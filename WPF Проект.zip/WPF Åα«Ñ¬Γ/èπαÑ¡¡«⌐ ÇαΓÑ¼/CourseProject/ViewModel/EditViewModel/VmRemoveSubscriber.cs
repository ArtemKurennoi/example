﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using CourseProject.Model;
using CourseProject.Querys;
using CourseProject.View.EditView;


namespace CourseProject.ViewModel.EditViewModel
{
    public class VmRemoveSubscriber
    {
        //объкт для запросов
        private readonly Query _query;
        //объект главной вью модели
        private PostOffice _postOffice;
        //все почтальоны
        public ObservableCollection<object> AllSubscribers { get; set; }

        //конструктор по умолчанию
        public VmRemoveSubscriber()
        {
            //создание коллекции
            AllSubscribers = new ObservableCollection<object>();

            //создаем объект
            _query = new Query();
        }

        public void RemoveSubscriber(PostOffice postOffice)
        {
            //запомнить ссылку
            _postOffice = postOffice;
            //чистим коллекцию
            AllSubscribers.Clear();

            //запрос к базе данных
            var temp = _query.AllSubscribers();

            //записываем в коллекцию
            foreach (var item in temp)
                AllSubscribers.Add(item);

            //создать окно
            RemoveSubscriber view = new RemoveSubscriber(this);

            //вывести
            view.Show();
            //выбрать нужного почтальона
            //при нажатии на кнопку ок запускаем событие 
            view.btnOk.Command = new Command(obj =>
            {

                if (view.dgSubscribers.SelectedItem == null)
                    MessageBox.Show("Выберите подписчика");
                else
                {
                    Remove(view.dgSubscribers.SelectedItem as Subscribers);
                    view.Close();
                }
            });
            //назначим на кнопку закрытие окна
            view.btnCancel.Command = new Command(obj => view.Close());

        }//RemoveSubscriber

        //удаление
        private void Remove(Subscribers subscriber)
        {
            //поставить отметку о неактуальности
            _query.RemoveSubscriber(subscriber);
            //изменить значение свойства, для срабатывания OnPropertyChanged
            //пересчитать почтальонов
            _postOffice.CountSubscribers = _query.CountSubscribers();
            //пересмотреть вывод
            _postOffice.OperatorCollectionChanges();
        }//Remove
    }
}
