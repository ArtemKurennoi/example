﻿using CourseProject.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseProject.ViewModel
{
    //классы для входа с разными интерфейсами
    public abstract class BaseRoleVm
    {
        public abstract string Name { get; }
    }//BaseRoleVm

    public class ManagerRoleVm : BaseRoleVm
    {
        public override string Name => "Manager";
    }//ManagerRoleVm

    public class OperatorRoleVm : BaseRoleVm
    {
        public override string Name => "Operator";
    }//OperatorRoleVm

    //процесс выбора интерфейсов
    public class Selection 
    {
        
        //команда зайти под Заведующим почтовым отделением
        private Command comeInManagerCommand;
        public Command ComeInManagerCommand =>
            comeInManagerCommand ??
            (comeInManagerCommand = new Command(obj => {
                //получаем окно входа из параметра
                MainWindow mainWindow = obj as MainWindow;
                //создаем окно и передаем роль
                ManagerView view = new ManagerView(new ManagerRoleVm());
                view.Show();
                //закрываем окно входа
                mainWindow.Close(); ;
            })); // ComeInManager


        //команда зайти под Оператором почтовой связи
        private Command comeInOperatorCommand;

        public Command ComeInOperatorCommand =>
            comeInOperatorCommand ??
            (comeInOperatorCommand = new Command(obj => {
                //получаем окно входа из параметра
                MainWindow mainWindow = obj as MainWindow;
                //создаем окно и передаем роль
                OperatorView view = new OperatorView(new OperatorRoleVm());
                view.Show();
                //закрываем окно входа
                mainWindow.Close(); 
            })); // ComeInOperator

    }//Selection

}
