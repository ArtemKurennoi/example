﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using CourseProject.Model;
using CourseProject.View;
using CourseProject.Querys;
using CourseProject.Context;
using CourseProject.View.EditView;
using CourseProject.View.ReportView;
using CourseProject.ViewModel.EditViewModel;

namespace CourseProject.ViewModel
{
    //Логика 
    //Заведующий почтовым отделением может принять на работу и уволить
    //почтальона, при этом участки не должны оставаться без обслуживания. 

    //Оператор почтовой связи должен иметь возможность по просьбе клиента
    //оформить подписку, а также добавить в БД сведения о новом подписном издании. 

    /*Оформление подписки связано с выдачей клиенту квитанции, в которой указывается
     общая стоимость подписки, что выписано, и на какой срок.*/

    //Запросы
    /*
    Возможны следующие запросы к БД:
    1.	Определить наименование и количество экземпляров всех изданий, получаемых отделением связи.
    2.	По заданному адресу определить фамилию почтальона, обслуживающего подписчика.
    3.	Какие газеты выписывает гражданин с указанной фамилией, именем, отчеством?
    4.	Сколько почтальонов работает в почтовом отделении?
    5.	На каком участке количество экземпляров подписных изданий максимально?
    6.	Каков средний срок подписки по каждому изданию?
*/

    //Справка
    /*Нужна справка о количестве подписчиков, количестве газет и количестве журналов,
     выписанных на текущий момент подписчиками.*/

    //Отчет
    /*Требуется формирование отчета о доставке почтой газет и журналов. Отчет должен быть
     упорядочен по участкам. Для каждого участка указывается фамилия и инициалы почтальона,
    обслуживающего участок, и перечень доставляемых изданий (индекс и название издания, 
    адрес доставки, срок подписки). По каждому изданию указывается средний срок подписки и
    количество экземпляров, а по участку – количество различных подписных изданий. 
В отчете должно быть указано сколько почтальонов работает в почтовом отделении, сколько 
    всего участков оно обслуживает, сколько различных изданий доставляет подписчикам.
*/

    //основная часть, загрузка данных, основные команды
    public partial class PostOffice : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        //объкт для запросов
        private readonly Query _query;


        #region Коллекции

        // коллекция для отображения в окнах пользователя
        public ObservableCollection<object> ManagerCollection { get; set; }
        public ObservableCollection<object> OperatorCollection { get; set; }



        #endregion

        #region Свойства

        //количество подписчиков
        private int countSubscribers;
        public int CountSubscribers
        {
            get => countSubscribers;
            set
            {
                countSubscribers = value;
                OnPropertyChanged("CountSubscribers");
            }
        }//CountPostmen

        //Количество газет
        private int countNewspapers;
        public int CountNewspapers
        {
            get => countNewspapers;
            set
            {
                countNewspapers = value;
                OnPropertyChanged("CountNewspapers");
            }
        }//CountNewspapers

        //Количество почтальонов 
        private int countPostmen;
        public int CountPostmen
        {
            get => countPostmen;
            set
            {
                countPostmen = value;
                OnPropertyChanged("CountPostmen");
            }
        }//CountPostmen

        //Количество журналов
        private int countMagazines;
        public int CountMagazines
        {
            get => countMagazines;
            set
            {
                countMagazines = value;
                OnPropertyChanged("CountMagazines");
            }
        }//CountMagazines

        #endregion


        //конструктор по умолчанию
        public PostOffice()
        {
            //коллекция для стартового вида
            ManagerCollection = new ObservableCollection<object>();
            OperatorCollection = new ObservableCollection<object>();
            //коллекции для отчетов и справок

            //создаем объект
            _query = new Query();

        }

        //конструктор с параметром
        public PostOffice(BaseRoleVm role)
        {
            //коллекция для стартового вида
            ManagerCollection = new ObservableCollection<object>();
            OperatorCollection = new ObservableCollection<object>();
            //создаем объект запросов с контекстом внутри
            _query = new Query();
            //исходя из роли пользователя формируем данные
            StartView(role);
        }

        //вывод при старте
        private void StartView(BaseRoleVm role)
        {

            switch (role.Name)
            {
                case "Manager":
                    //загрузка стартового представления
                    InitialViewManager();
                    break;

                case "Operator":
                    //загрузка стартового представления
                    InitialViewOperator();
                    break;
            }
        } //StartView

        //команда выход
        private Command quitCommand;

        public Command QuitCommand =>
            quitCommand ??
            (quitCommand = new Command(obj => Application.Current.Shutdown()));

        //команда открыть окно о разработчике
        private Command aboutCommand;

        public Command AboutCommand =>
            aboutCommand ??
            (aboutCommand = new Command(obj => new AboutView().Show()));

        //при старте от оператора видим подписчиков и издания
        private void InitialViewOperator()
        {
            //инициализация свойств
            CountSubscribers = _query.CountSubscribers();
            CountNewspapers = _query.CountNewspapers();
            CountPostmen = _query.CountPostmen();
            CountMagazines = _query.CountMagazines();
            //запись в привязаную коллекцию
            OperatorCollectionChanges();

        } // InitialViewOperator

        //при старте от заведующего видим почтальонов и участки
        private void InitialViewManager()
        {
            //инициализация свойств
            //в StatusBar
            CountSubscribers = _query.CountSubscribers();
            CountNewspapers = _query.CountNewspapers();
            CountPostmen = _query.CountPostmen();
            CountMagazines = _query.CountMagazines();
            //запись в привязаную коллекцию
            ManagerCollectionChanges();

        } // InitialViewManager

        //чтение данных из бд и перенос в привязанную коллекцию
        public void ManagerCollectionChanges()
        {
            //чистим коллекцию
            ManagerCollection.Clear();
            //запрос к базе данных
            var temp = _query.ViewManager();
            
            //записываем в коллекцию
            foreach (var item in temp)
                ManagerCollection.Add(item);
        }//ManagerCollectionChanges

        //чтение данных из бд и перенос в привязанную коллекцию
        public void OperatorCollectionChanges()
        {
            //чистим коллекцию
            OperatorCollection.Clear();

            //запрос к базе данных
            var temp = _query.ViewOperator() as List<Subscriptions>;

            //записываем в коллекцию
            foreach (var item in temp)
                OperatorCollection.Add(item);
        }//OperatorCollectionChanges


        //извенения свойств
        public void OnPropertyChanged([CallerMemberName] string prop = "") =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
        

    }//ViewPostOffice
}
