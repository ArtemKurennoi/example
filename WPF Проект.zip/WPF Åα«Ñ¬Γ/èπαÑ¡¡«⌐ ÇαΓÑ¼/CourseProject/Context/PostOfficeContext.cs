﻿using CourseProject.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseProject.Context
{
    //Представление БД
    class PostOfficeContext : DbContext
    {
        public PostOfficeContext()
            : base("name=PostOfficeContainer")
        {
            //переход на 2 каталога выше
            var path = Directory.GetParent(Directory.GetParent(Directory.GetCurrentDirectory()).FullName).FullName;

            //задаем для DataDirectory нужный нам путь, для работы в App.config
            AppDomain.CurrentDomain.SetData("DataDirectory", path);

            //инициализатор базы данных
            Database.SetInitializer(new PostOfficeInit());
        }

        // Таблицы БД
        public virtual DbSet<Postmen> Postmen { get; set; }
        public virtual DbSet<PublicationTypes> PublicationTypes { get; set; }
        public virtual DbSet<Publications> Publications { get; set; }
        public virtual DbSet<Districts> Districts { get; set; }
        public virtual DbSet<Addresses> Addresses { get; set; }
        public virtual DbSet<Subscribers> Subscribers { get; set; }
        public virtual DbSet<Subscriptions> Subscriptions { get; set; }
    }//CodeContext
}
