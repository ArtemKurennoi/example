﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using CourseProject.Model;

namespace CourseProject.Context
{
    //не происходит инициализация
    //class PostOfficeInit : DropCreateDatabaseIfModelChanges<PostOfficeContext>
    class PostOfficeInit : DropCreateDatabaseAlways<PostOfficeContext>
    {
        // метод генерации данных 
        protected override void Seed(PostOfficeContext context)
        {
            base.Seed(context);


            //типы изданий
            context.PublicationTypes.AddRange(new[] {
                new PublicationTypes { TypeName = "газета" },
                new PublicationTypes { TypeName = "журнал" },
                new PublicationTypes { TypeName = "каталог" },
                new PublicationTypes { TypeName = "альманах" },
                new PublicationTypes { TypeName = "дайджест" },
                new PublicationTypes { TypeName = "бюллетень" },
                new PublicationTypes { TypeName = "календарь" },
                new PublicationTypes { TypeName = "сборник" },
                new PublicationTypes { TypeName = "информация" },
                new PublicationTypes { TypeName = "рефераты" }});
            context.SaveChanges();

            //почтальоны
            context.Postmen.AddRange(new[] {
                new Postmen { Surname = "Иванов", Name = "Илья", Patronymic = "Евгеньевич" },
                new Postmen { Surname="Петров",  Name="Егор" ,    Patronymic="Аркадьевич"},
                new Postmen { Surname="Ахметов", Name="Владимир" ,Patronymic="Ярославович"},
                new Postmen { Surname= "Черышев",Name="Артем" ,   Patronymic="Дмитриевич"} });
            context.SaveChanges();

            //участки
            context.Districts.AddRange(new[]
            {
                new Districts {Number=1,DistrictName="Север",PostmenId=1},
                new Districts {Number=2,DistrictName="Юг",PostmenId=2},
                new Districts {Number=3,DistrictName="Запад",PostmenId=3},
                new Districts {Number=4,DistrictName="Восток",PostmenId=4}
            });
            context.SaveChanges();

            //адреса
            context.Addresses.AddRange(new[]
            {
                new Addresses {Street="Мира", House ="2в" , Apartment=51   , DistrictId=1},
                new Addresses {Street="Мира", House ="51" , Apartment=5    , DistrictId=1},
                new Addresses {Street="Артема", House ="269" , Apartment=1  , DistrictId=2},
                new Addresses {Street="Ватутина", House ="3б" , Apartment=24 , DistrictId=2},
                new Addresses {Street="Ленина", House ="28а" , Apartment=99 , DistrictId=3},
                new Addresses {Street="Артема", House ="110" , Apartment=110 , DistrictId=3},
                new Addresses {Street="Ватутина", House ="150" , Apartment=1  , DistrictId=4},
                new Addresses {Street="Щорса", House ="78" , Apartment=22   , DistrictId=4},
                new Addresses {Street="Мира", House ="124" , Apartment=34   , DistrictId=2},
                new Addresses {Street="Тельмана", House ="34" , Apartment=7  , DistrictId=3},
            });
            context.SaveChanges();

            //издания
            context.Publications.AddRange(new[]
            {
                new Publications { PublicationIndex="Е27818",Title="Травинка", Price=190 ,PublicationTypeId=1},
                new Publications { PublicationIndex="Е10628",Title="Адвокатская газета", Price=263   ,PublicationTypeId=1},
                new Publications { PublicationIndex="А42488",Title="Астролог", Price=198 ,PublicationTypeId=4},
                new Publications { PublicationIndex="Э32128",Title="АиФ. Здоровье", Price=142    ,PublicationTypeId=1},
                new Publications { PublicationIndex="Е83809",Title="33 совета", Price=90 ,PublicationTypeId=2},
                new Publications { PublicationIndex="Ц34174",Title="Наука и жизнь", Price=543    ,PublicationTypeId=2},
                new Publications { PublicationIndex="Е39391",Title="Программирование", Price=1103    ,PublicationTypeId=2},
                new Publications { PublicationIndex="И82198",Title="Программирование на C#", Price=1125  ,PublicationTypeId=2},
                new Publications { PublicationIndex="Е13133",Title="Известия", Price=846 ,PublicationTypeId=1},
                new Publications { PublicationIndex="Е11450",Title="Добрая Дорога Детства", Price=119    ,PublicationTypeId=1},
                new Publications { PublicationIndex="А87407",Title="Юрист и закон", Price=1710   ,PublicationTypeId=4},
                new Publications { PublicationIndex="Е39549",Title="Здоровым быть!", Price=50    ,PublicationTypeId=1},
                new Publications { PublicationIndex="Ц86443",Title="Таможня в РФ и за рубежом", Price=20497,PublicationTypeId=2},
                new Publications { PublicationIndex="Е13150",Title="Театр", Price=533    ,PublicationTypeId=2},
                new Publications { PublicationIndex="Э89032",Title="Радио", Price=512    ,PublicationTypeId=2},
                new Publications { PublicationIndex="Е00091",Title="Мир офтальмологии", Price=669    ,PublicationTypeId=1},
                new Publications { PublicationIndex="Е43246",Title="Мурзилка", Price=320 ,PublicationTypeId=2},
                new Publications { PublicationIndex="Э11750",Title="Аргументы и факты", Price=333    ,PublicationTypeId=1},
                new Publications { PublicationIndex="Е82228",Title="Воздушный транспорт гражданской авиации", Price=932  ,PublicationTypeId=1},
                new Publications { PublicationIndex="Р80475",Title="Вокруг света", Price=378 ,PublicationTypeId=2},
                new Publications { PublicationIndex="Е50102",Title="Правда", Price=304   ,PublicationTypeId=1},
                new Publications { PublicationIndex="Э33193",Title="Правовой эксперт", Price=1710    ,PublicationTypeId=1},
                new Publications { PublicationIndex="Е29461",Title="Пуговка", Price=610  ,PublicationTypeId=1},
                new Publications { PublicationIndex="Э50191",Title="Земля и люди", Price=730 ,PublicationTypeId=1},
                new Publications { PublicationIndex="А67889",Title="Поэзия весны", Price=560   ,PublicationTypeId=4}
            });
            context.SaveChanges();

            //подписчики
            context.Subscribers.AddRange(new[]
            {
                new Subscribers { Surname="Коралев", Name="Иван", Patronymic="Евгеньевич", AddressId=1},
                new Subscribers { Surname="Викторов", Name="Сергей", Patronymic="Аркадьевич", AddressId=2},
                new Subscribers { Surname="Комаров", Name="Виктор", Patronymic="Ярославович", AddressId=3},
                new Subscribers { Surname="Кружкин", Name="Андрей", Patronymic="Дмитриевич", AddressId=4},
                new Subscribers { Surname="Легасов", Name="Геннадий", Patronymic="Генадьевич", AddressId=5},
                new Subscribers { Surname="Водянов", Name="Олег", Patronymic="Сергеевич", AddressId=6},
                new Subscribers { Surname="Крамченко", Name="Владимир", Patronymic="Едуардович", AddressId=7},
                new Subscribers { Surname="Каприн", Name="Сергей", Patronymic="Андреевич", AddressId=8},
                new Subscribers { Surname="Мавлен", Name="Владислав", Patronymic="Викторович", AddressId=9},
                new Subscribers { Surname="Купринов", Name="Даниил", Patronymic="Олегович", AddressId=10},
            });
            context.SaveChanges();

            //подписки 12
            context.Subscriptions.AddRange(new[]
            {
                new Subscriptions{StartDate=new DateTime(2021, 08, 24), Duration=12, PublicationId=1, SubscriberId=1 },
                new Subscriptions{StartDate=new DateTime(2021, 02, 27), Duration=10, PublicationId=2, SubscriberId=2 },
                new Subscriptions{StartDate=new DateTime(2021, 03, 07), Duration=11, PublicationId=3, SubscriberId=3 },
                new Subscriptions{StartDate=new DateTime(2021, 07, 30), Duration=5, PublicationId=4, SubscriberId=4 },
                new Subscriptions{StartDate=new DateTime(2021, 07, 19), Duration=7, PublicationId=2, SubscriberId=5 },
                new Subscriptions{StartDate=new DateTime(2021, 02, 15), Duration=12, PublicationId=1, SubscriberId=6 },
                new Subscriptions{StartDate=new DateTime(2021, 08, 24), Duration=3, PublicationId=1, SubscriberId=7 },
                new Subscriptions{StartDate=new DateTime(2021, 09, 16), Duration=6, PublicationId=2, SubscriberId=8 },
                new Subscriptions{StartDate=new DateTime(2021, 08, 01), Duration=6, PublicationId=3, SubscriberId=9 },
                new Subscriptions{StartDate=new DateTime(2021, 05, 16), Duration=12, PublicationId=4, SubscriberId=10 },
                new Subscriptions{StartDate=new DateTime(2021, 04, 16), Duration=10, PublicationId=5, SubscriberId=1 },
                new Subscriptions{StartDate=new DateTime(2021, 09, 16), Duration=2, PublicationId=9, SubscriberId=1 },
                new Subscriptions{StartDate=new DateTime(2021, 07, 19), Duration=7, PublicationId=1, SubscriberId=5 },
            });
            context.SaveChanges();

        }
    }
}
