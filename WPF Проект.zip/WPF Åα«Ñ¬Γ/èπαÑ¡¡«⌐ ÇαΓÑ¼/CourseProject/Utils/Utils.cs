﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseProject.Utils
{
    public static class Utils
    {
        // объект для случайных чисел
        public static readonly Random Random = new Random(Environment.TickCount);
        //генерация данных целые числа
        public static int GetRand(int low, int high) => Random.Next(low, high);
        //генерация данных вещественные числа
        public static double GetRand(double low, double high) => low + (high - low) * Random.NextDouble();

    }//Utils
     //создание метода ToObservableCollection
    public static class Extensions
    {
        public static ObservableCollection<T> ToObservableCollection<T>(this IEnumerable<T> collection) =>
            new ObservableCollection<T>(collection);
    }//Extensions
}
