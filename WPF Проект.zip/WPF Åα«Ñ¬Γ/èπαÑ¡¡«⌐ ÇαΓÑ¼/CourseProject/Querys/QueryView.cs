﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourseProject.Model;

namespace CourseProject.Querys
{
    public partial class Query
    {
        //стартовый вид для оператора
        public IEnumerable ViewOperator() =>
            (from item in _db.Subscriptions
             //только актуальные
             where item.Publication.Relevance && item.Subscriber.Relevance
                select new
                {
                    item.Id,
                    item.Duration,
                    item.StartDate,
                    item.PublicationId,
                    PublicationTitle = item.Publication.Title,
                    PublicationPrice = item.Publication.Price,
                    item.Publication.PublicationIndex,
                    SubscriberSurname = item.Subscriber.Surname,
                    SubscriberName = item.Subscriber.Name,
                    SubscriberPatronymic = item.Subscriber.Patronymic,
                }).AsEnumerable() //для создания коллекции с типом (Subscriptions)
            .Select(item => new Subscriptions
            {
                Id = item.Id,
                Duration = item.Duration,
                StartDate = item.StartDate,
                Publication = new Publications { Title = item.PublicationTitle, Price = item.PublicationPrice, PublicationIndex = item.PublicationIndex },
                Subscriber = new Subscribers { Surname = item.SubscriberSurname, Name = item.SubscriberName, Patronymic = item.SubscriberPatronymic }
            }).ToList();


        #region Представления для стартового вида пользователей
        //стартовый вид для заведующего
        public IEnumerable ViewManager()
        {
            var query = from p in _db.Postmen
                        where p.Relevance
                        join d in _db.Districts on p equals d.Postmen into temp
                        from item in temp.DefaultIfEmpty()
                        select new
                        {
                            Number = item.Number == null ? 0 : item.Number,
                            DistrictName = item.DistrictName ?? "Район не назначен",
                            PostmanSurname = p.Surname,
                            PostmanName = p.Name,
                            PostmanPatronymic = p.Patronymic
                        };
            return query.ToList();
        }//ViewManager

        #endregion
    }//Query
}
