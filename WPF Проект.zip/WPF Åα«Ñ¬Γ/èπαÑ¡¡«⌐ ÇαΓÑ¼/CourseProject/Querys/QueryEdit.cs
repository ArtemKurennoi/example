﻿using CourseProject.Context;
using CourseProject.Model;
using CourseProject.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CourseProject.Utils.Utils;

namespace CourseProject.Querys
{
    public partial class Query
    {
        #region Добавление и удаление участков
        //запрос который предоставляет все издания
        public ObservableCollection<Publications> AllPublications() =>
        (from item in _db.Publications
         where item.Relevance
         select new
         {
             item.Id,
             item.Title,
             item.PublicationIndex,
             item.PublicationType.TypeName,
             item.Price
         }).AsEnumerable()
            .Select(x => new Publications
            {
                Id = x.Id,
                Title = x.Title,
                PublicationIndex = x.PublicationIndex,
                Price = x.Price,
                PublicationType = new PublicationTypes { TypeName = x.TypeName }
            }).ToObservableCollection();

        //удаление участков
        public void RemovePublication(Publications publication)
        {
            //выбрали
            var temp = _db.Publications.Find(publication.Id);
            //проставили отметку что не использывается
            temp.Relevance = false;
            //сохранили
            _db.SaveChanges();
        }//RemovePostman

        //проверка публикации в базе данных
        public bool CheckPublication(Publications publication)
        {
            var temp =
                (from item in _db.Publications
                 where item.PublicationIndex == publication.PublicationIndex
                 select new
                 {
                     item.Id,
                     item.Title,
                     item.PublicationIndex,
                     item.Price
                 }).ToList();

            return temp.Count > 0;
        }//CheckPublication

        public ObservableCollection<PublicationTypes> AllType() =>
        (from item in _db.PublicationTypes
         select new
         {
             item.Id,
             item.TypeName
         }).AsEnumerable()
            .Select(x => new PublicationTypes
            {
                Id = x.Id,
                TypeName = x.TypeName,
            }).ToObservableCollection();

        //добавление
        public void AddPublication(Publications publication)
        {
            //добавление
            _db.Publications.Add(publication);

            //сохранение
            _db.SaveChanges();
        }//AddPostman
        #endregion

        #region Добавление и удаление подписчиков и оформление подписки

        //запрос который предоставляет всех подписчиков
        public ObservableCollection<Subscribers> AllSubscribers() =>
        (from item in _db.Subscribers
         where item.Relevance
         select new
         {
             item.Id,
             item.Surname,
             item.Name,
             item.Patronymic,
         }).AsEnumerable()
            .Select(x => new Subscribers
            {
                Id = x.Id,
                Surname = x.Surname,
                Name = x.Name,
                Patronymic = x.Patronymic,
            }).ToObservableCollection();

        //добавление в таблицу подписок(оформление подписки)
        public void AddSubscription(Subscriptions subscription)
        {
            //добавление
            _db.Subscriptions.Add(subscription);

            //сохранение
            _db.SaveChanges();
        }//AddSubscription

        //удаление подписчика
        public void RemoveSubscriber(Subscribers subscriber)
        {
            //выбрали
            var temp = _db.Subscribers.Find(subscriber.Id);
            //проставили отметку что не использывается
            temp.Relevance = false;
            //сохранили
            _db.SaveChanges();
        }//RemoveSubscriber

        //проверка подписчика в базе данных
        public bool CheckSubscriber(Subscribers subscriber)
        {
            var temp =
                (from item in _db.Subscribers
                 where item.Surname == subscriber.Surname &&
                      item.Name == subscriber.Name &&
                      item.Patronymic == subscriber.Patronymic
                 select new
                 {
                     item.Id,
                     item.Surname,
                     item.Name,
                     item.Patronymic
                 }).ToList();

            return temp.Count > 0;

        }//CheckPublication

        //добавление подписчика
        public void AddSubscriber(Subscribers subscriber)
        {
            //добавление
            _db.Subscribers.Add(subscriber);

            //сохранение
            _db.SaveChanges();
        }//AddSubscriber
        #endregion


        #region Добавление и удаление почтальона, изменения района для почтальона
        //все почтальоны
        public ObservableCollection<Postmen> AllPostmen() =>
        (from item in _db.Postmen
         where item.Relevance
         select new
         {
             item.Id,
             item.Surname,
             item.Name,
             item.Patronymic
         }).AsEnumerable()
            .Select(x => new Postmen
            {
                Id = x.Id,
                Surname = x.Surname,
                Name = x.Name,
                Patronymic = x.Patronymic
            }).ToObservableCollection();

        //проверка почтальона в базе данных
        public bool CheckPostman(Postmen postman)
        {
            var temp =
                (from item in _db.Postmen
                 where item.Surname == postman.Surname &&
                       item.Name == postman.Name &&
                       item.Patronymic == postman.Patronymic
                 select new
                 {
                     item.Id,
                     item.Surname,
                     item.Name,
                     item.Patronymic
                 }).ToList();

            return temp.Count > 0;
        }//CheckPostman

        //добавление
        public void AddPostman(Postmen postman)
        {
            var a = (from item in _db.Postmen
                     select new
                     {
                         item.Id,
                         item.Surname,
                         item.Name,
                         item.Patronymic
                     }).ToList();
            var b = (from item in _db.Districts
                     select new
                     {
                         item.Id,
                         item.Addresses,
                         item.DistrictName,
                         item.Number,
                         item.Postmen,
                         item.PostmenId,
                     }).ToList();
            //добавление
            _db.Postmen.Add(postman);
            //по заданию участок обслуживается одним почтальоном;
            //добавить новый участок для почтальона 
            //привязка почтальона к участку - отдельный метод

            //сохранение
            _db.SaveChanges();
        }//AddPostman

        //увольнение
        public void RemovePostman(Postmen postman)
        {
            //выбрали
            var temp = _db.Postmen.Find(postman.Id);
            //проставили отметку что не использывается
            temp.Relevance = false;
            //сохранили
            _db.SaveChanges();
        }//RemovePostman

        //проверка есть ли на участке почтальон
        public bool CheckDistricts(Postmen postman)
        {
            //выбираем участок с нужным почтальоном
            var district = (from item in _db.Districts
                            where item.Postmen.Id == postman.Id
                            select new
                            {
                                item.Id,
                                item.DistrictName,
                                item.Number,
                                item.Postmen,
                                item.PostmenId,
                            }).AsEnumerable()
            .Select(x => new Districts
            {
                Id = x.Id,
                DistrictName = x.DistrictName,
                Number = x.Number,
                Postmen = new Postmen { Id = x.Postmen.Id, Relevance = x.Postmen.Relevance },
                PostmenId = x.PostmenId
            }).ToList();

            //0 = почтальон не привязан к участку (на участках нет этого почтальона)

            //>0 участок нужно перераспределить
            return district.Count > 0;

        }//CheckDistricts

        //перераспределение участка у которого нужно удалить почтальона
        //добавляет нового почтальона!
        public void DistributionDistricts(Postmen postman)
        {
            //выбираем участок/участки с нужным почтальоном
            var districts = (from item in _db.Districts
                             where item.Postmen.Id == postman.Id
                             select new
                             {
                                 item.Id,
                                 item.DistrictName,
                                 item.Number,
                                 item.Postmen,
                                 item.PostmenId,
                             }).AsEnumerable()
            .Select(x => new Districts
            {
                Id = x.Id,
                DistrictName = x.DistrictName,
                Number = x.Number,
                Postmen = new Postmen { Id = x.Postmen.Id, Relevance = x.Postmen.Relevance },
                PostmenId = x.PostmenId
            }).ToList();

            //почтальоны
            var postmens = (from item in _db.Postmen
                            where item.Relevance
                            select new
                            {
                                item.Id,
                                item.Surname,
                                item.Name,
                                item.Patronymic
                            }).AsEnumerable()
                     .Select(item => new Postmen
                     {
                         Id = item.Id,
                         Surname = item.Surname,
                         Name = item.Name,
                         Patronymic = item.Patronymic
                     }).ToList();

            //выбрали участок
            foreach (var item in districts)
            {
                //участок в котором нужно заменить почтальона
                var tmp = _db.Districts.Find(item.Id);
                var rndPostman = _db.Postmen.Find(postmens[GetRand(0, postmens.Count)].Id);
                //замена
                tmp.Postmen = rndPostman;
            }//foreach

            //сохранили
            _db.SaveChanges();

        }//DistributionDistricts


        //все районы
        public ObservableCollection<Districts> AllDistricts() =>
        (from item in _db.Districts
         select new
         {
             item.Id,
             item.Number,
             item.DistrictName,
             item.Postmen
         }).AsEnumerable()
            .Select(x => new Districts
            {
                Id = x.Id,
                Number = x.Number,
                DistrictName = x.DistrictName,
                Postmen = x.Postmen
            }).ToObservableCollection();
        //изменить район

        //поиск одного почтальона по ид
        public Postmen SelectPostman(int? id)=>
             (from item in _db.Postmen
                        //только актуальные
                    where item.Relevance &&
                          item.Id==id
                    select new
                    {
                        item.Id,
                        item.Surname,
                        item.Name,
                        item.Patronymic
                    }).AsEnumerable()
            .Select(x => new Postmen
            {
                Id=x.Id,
                Surname = x.Surname,
                Name = x.Name,
                Patronymic = x.Patronymic
            }).FirstOrDefault();

        //поиск одного района по ид
        public Districts SelectDistrict(int? id)
        {
            return (from item in _db.Districts
                    where item.Id == id 
                    select new
                    {
                        item.Id,
                        item.Number,
                        item.DistrictName,
                        item.Postmen
                    }).AsEnumerable()
            .Select(x => new Districts
            {
                Id = x.Id,
                Number = x.Number,
                DistrictName = x.DistrictName,
                Postmen = x.Postmen
            }).FirstOrDefault();
        }//SelectPostman

        public void ChangePostman(Districts district, Postmen postman)
        {
            //выбираем нужный участок
            var tmpDistrict = (from item in _db.Districts
                             where item.Id == district.Id
                             select new
                             {
                                 item.Id,
                                 item.DistrictName,
                                 item.Number,
                                 item.Postmen,
                                 item.PostmenId,
                             }).AsEnumerable()
            .Select(x => new Districts
            {
                Id = x.Id,
                DistrictName = x.DistrictName,
                Number = x.Number,
                Postmen = new Postmen { Id = x.Postmen.Id, Relevance = x.Postmen.Relevance },
                PostmenId = x.PostmenId
            }).FirstOrDefault();

            //почтальон
            var tmpPostman = (from item in _db.Postmen
                            where item.Relevance &&
                                  item.Id==postman.Id
                            select new
                            {
                                item.Id,
                                item.Surname,
                                item.Name,
                                item.Patronymic
                            }).AsEnumerable()
                     .Select(item => new Postmen
                     {
                         Id = item.Id,
                         Surname = item.Surname,
                         Name = item.Name,
                         Patronymic = item.Patronymic
                     }).FirstOrDefault();

            //выбрали участок по ид
            var tmpDbDistr = _db.Districts.Find(tmpDistrict.Id);
            //выбрали почтальона по ид
            var tmpNewPostman = _db.Postmen.Find(tmpPostman.Id);
            //замена
            tmpDbDistr.Postmen = tmpNewPostman;
            //сохранили
            _db.SaveChanges();

        }//ChangePostman

        #endregion
    }
}
