﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CourseProject.Model;
using CourseProject.Utils;

namespace CourseProject.Querys
{
    public partial class Query
    {
        #region Запросы для отчетов
        /*Требуется формирование отчета о доставке почтой газет и журналов. Отчет должен быть
         упорядочен по участкам. Для каждого участка указывается фамилия и инициалы почтальона,
        обслуживающего участок, и перечень доставляемых изданий (индекс и название издания, 
        адрес доставки, срок подписки). По каждому изданию указывается средний срок подписки и
        количество экземпляров, а по участку – количество различных подписных изданий. 
        В отчете должно быть указано сколько почтальонов работает в почтовом отделении, сколько 
        всего участков оно обслуживает, сколько различных изданий доставляет подписчикам.
        */

        //сколько всего участков оно обслуживает
        public int CountDistricts() =>
            (from item in _db.Districts
                 //считаем только актуальных
             select new
             {
                 item.Id,
             }).Count();

        //сколько различных изданий доставляет подписчикам.
        public int CountDistinctPubl() =>
            (from item in _db.Subscriptions
                 //считаем только актуальных
             where item.Publication.Relevance
             select new
             {
                 item.PublicationId,
             }).Distinct()
            .Count();

        public IEnumerable DeliveryReport()
        {
            //По каждому изданию указывается средний срок подписки и
            // количество экземпляров
            var avgDuration = (from item in _db.Subscriptions
                               select new
                               {
                                   PublicationId = item.Publication.Id,
                                   item.Duration,
                                   item.Id
                               }).GroupBy(x => x.PublicationId,
                    (key, group) => new
                    {
                        PublicationId = key,
                        PublicationCount = group.Count(),
                        AvgSubscription = group.Average(x => x.Duration)
                    }).ToList();

            //по участку – количество различных подписных изданий. -правильно
            var publicationDistinct = (from item in _db.Subscriptions
                                       select new
                                       {
                                           PublicationId = item.Publication.Id,
                                           DistrictId = item.Subscriber.Address.District.Id,
                                           DistrictNumber = item.Subscriber.Address.District.Number,
                                       }).GroupBy(x => new { x.DistrictId, x.DistrictNumber },
                (key, group) => new
                {
                    key.DistrictNumber,
                    PublicationDistinct = group.Distinct(),
                }).ToList();

            //оснавная выборка данных
            var temp = (from item in _db.Subscriptions
                        where //только актуальные
                              item.Subscriber.Relevance &&
                              item.Publication.Relevance &&
                              item.Subscriber.Address.District.Postmen.Relevance &&
                            (item.Publication.PublicationType.TypeName == "газета" ||
                            item.Publication.PublicationType.TypeName == "журнал")
                        select new
                        {
                            DistrictNumber = item.Subscriber.Address.District.Number,
                            item.Subscriber.Address.District.Postmen.Surname,
                            item.Subscriber.Address.District.Postmen.Name,
                            item.Subscriber.Address.District.Postmen.Patronymic,
                            item.Publication.PublicationIndex,
                            item.PublicationId,
                            item.Publication.Title,
                            item.Subscriber.Address.Street,
                            item.Subscriber.Address.House,
                            item.Subscriber.Address.Apartment,
                            item.Duration
                        }).AsEnumerable()
                .Select(x => new
                {
                    x.DistrictNumber,
                    SurnameNP = $"{x.Surname} {x.Name.FirstOrDefault()}.{x.Patronymic.FirstOrDefault()}",
                    x.PublicationIndex,
                    x.PublicationId,
                    x.Title,
                    Address = $"Ул.{x.Street}, д.{x.House}, кв.{x.Apartment}",
                    x.Duration
                }).OrderBy(x => x.DistrictNumber)
                .ToList();

            //объединения
            var union = temp.Join(publicationDistinct,
                t => t.DistrictNumber,
                p => p.DistrictNumber,
                (t, p) => new
                {
                    t.DistrictNumber,
                    t.SurnameNP,
                    t.PublicationIndex,
                    t.PublicationId,
                    t.Title,
                    t.Address,
                    t.Duration,
                    PublicationDistinct = p.PublicationDistinct.Count()
                }).ToList();

            //объеденения и финальный результат
            var res = union.Join(avgDuration,
                u => u.PublicationId,
                a => a.PublicationId,
                (u, a) => new
                {
                    u.DistrictNumber,
                    u.SurnameNP,
                    u.PublicationIndex,
                    u.Title,
                    u.Address,
                    u.Duration,
                    u.PublicationDistinct,
                    //средний срок подписки и количество экземпляров
                    a.PublicationCount,
                    a.AvgSubscription
                }).ToList();

            return res;
        }//DeliveryReport


        //почтальоны по ид участку
        public ObservableCollection<Postmen> SelectPostmen(int? id)=>
             (from item in _db.Districts
                    where item.Id == id &&
                          //только актуальные
                          item.Postmen.Relevance
                    select new
                    {
                        item.Postmen.Id,
                        item.Postmen.Surname,
                        item.Postmen.Name,
                        item.Postmen.Patronymic
                    }).AsEnumerable()
            .Select(x => new Postmen
            {
                Surname = x.Surname,
                Name = x.Name,
                Patronymic = x.Patronymic
            }).ToObservableCollection();

        //газеты по ид подписчика
        public ObservableCollection<Publications> SelectNewspapers(int? subscriberId) =>
            (from item in _db.Subscriptions
             where item.Subscriber.Id == subscriberId &&
                   //только актуальные
                   item.Subscriber.Relevance &&
                   item.Publication.PublicationType.TypeName == "газета"
             select new
             {
                 item.Publication.Id,
                 item.Publication.PublicationIndex,
                 item.Publication.Title,
                 item.Publication.PublicationType.TypeName,
                 item.Publication.Price
             }).AsEnumerable()
                .Select(x => new Publications
                {
                    PublicationIndex = x.PublicationIndex,
                    Title = x.Title,
                    Price = x.Price,
                    PublicationType = new PublicationTypes { TypeName = x.TypeName }
                }).ToObservableCollection();

        //участок с максимальным количеством экземпляров 
        //TODO оптимизация )
        public IEnumerable DistrictMaxNum()
        {
            //сначала найти максимальный
            var max = (from item in _db.Subscriptions
                           //только актуальные
                       where item.Publication.Relevance
                       select new
                       {
                           item.Subscriber.Address.District.Number,
                           item.PublicationId
                       }).GroupBy(temp => temp.Number,
                    (key, group) => new
                    {
                        key,
                        MaxNumber = group.Count()
                    }).OrderByDescending(x => x.MaxNumber)
                .First().MaxNumber;


            //потом вернуть такие участки(если их несколько)
            return (from item in _db.Subscriptions
                        //только актуальные
                    where item.Publication.Relevance &&
                          item.Subscriber.Relevance
                    select new
                    {
                        item.Subscriber.Address.District.Number,
                        item.Subscriber.Address.District.DistrictName,
                        item.PublicationId
                    }).GroupBy(temp => new
                    { temp.Number, temp.DistrictName },
                    (key, group) => new
                    {
                        key.Number,
                        key.DistrictName,
                        MaxNumber = group.Count()
                    }).Where(x => x.MaxNumber == max)
                .ToList();
        }//DistrictMaxNum

        //средний срок подписки
        public IEnumerable AvgSubscription() =>
            (from item in _db.Subscriptions
                 //только актуальные
             where item.Publication.Relevance
             select new
             {
                 item.Id,
                 item.Publication.PublicationIndex,
                 item.Publication.Title,
                 item.Publication.PublicationType.TypeName,
                 item.Duration

             }).GroupBy(temp => new
             { temp.PublicationIndex, temp.Title, temp.TypeName },
                (key, group) => new
                {
                    key.Title,
                    key.PublicationIndex,
                    key.TypeName,
                    AvgSubscription = group.Average(x => x.Duration)
                }).ToList();

        #endregion
    }//QueryReports
}
