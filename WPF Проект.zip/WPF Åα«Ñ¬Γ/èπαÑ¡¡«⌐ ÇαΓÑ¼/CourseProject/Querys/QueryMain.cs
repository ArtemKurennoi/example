﻿using CourseProject.Context;
using CourseProject.Model;
using CourseProject.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CourseProject.Utils.Utils;

namespace CourseProject.Querys
{
    //запросы и представление
    public partial class Query
    {
        //объект для доступа к базе данных
        private static PostOfficeContext _db;

        public Query()
        {
            //context базы данных со свойствами
            _db = new PostOfficeContext();
        }



        #region Запросы для свойств viewmodels

        //количество почтальонов
        public int CountPostmen() =>
            (from item in _db.Postmen
                //считаем только актуальных
                where item.Relevance
             select new
                {
                    item.Id,
                }).Count();

        //Количество газет
        public int CountNewspapers() =>
            (from item in _db.Publications
                 //считаем только актуальных
             where item.PublicationType.TypeName == "газета" &&
                      item.Relevance
                select new
                {
                    item.Id,
                }).Count();

        //Количество журналов
        public int CountMagazines() =>
            (from item in _db.Publications
                //считаем только актуальных
             where item.PublicationType.TypeName == "журнал"
                      &&
                      item.Relevance
             select new
                {
                    item.Id,
                }).Count();


        //количество подписчиков
        public int CountSubscribers() =>
            (from item in _db.Subscribers
                //считаем только актуальных
                where item.Relevance
             select new
                {
                    item.Id,
                }).Count();

        #endregion

        #region Вспомогательные запросы

        //найти последнюю для квитанции
        public Subscriptions SelectSubscription(Subscriptions newSubscription) =>
            (from item in _db.Subscriptions
             where item.PublicationId == newSubscription.PublicationId &&
                      item.SubscriberId==newSubscription.SubscriberId &&
                      item.Duration == newSubscription.Duration &&
                      item.StartDate == newSubscription.StartDate
             select new
                {
                    item.Subscriber.Surname,
                    item.Subscriber.Name,
                    item.Subscriber.Patronymic,
                    item.Publication.Title,
                    item.Publication.PublicationIndex,
                    item.Publication.Price,
                    item.Duration,
                    item.StartDate,
                }).AsEnumerable()
            .Select(item => new Subscriptions
            {
                Duration = item.Duration,
                StartDate = item.StartDate,
                Publication = new Publications {Title = item.Title,PublicationIndex = item.PublicationIndex,Price = item.Price},
                Subscriber = new Subscribers {Surname = item.Surname,Name = item.Name,Patronymic = item.Patronymic}
            }).LastOrDefault();


        //все подписчики у которых газета
        //группировка что бы не дуплировались подписчики у которых несколько подписок
        public ObservableCollection<Subscribers> SelectSubscribers() =>
            (from item in _db.Subscriptions
                where item.Publication.PublicationType.TypeName == "газета" &&
                      //считаем только актуальных
                      item.Subscriber.Relevance
                select new
                {
                    item.Subscriber.Id,
                    item.Subscriber.Surname,
                    item.Subscriber.Name,
                    item.Subscriber.Patronymic,
                }).AsEnumerable()
            .GroupBy(x => new { x.Surname, x.Name, x.Patronymic, x.Id })
            .Select(item => new Subscribers
            {
                Id = item.Key.Id,
                Surname = item.Key.Surname,
                Name = item.Key.Name,
                Patronymic = item.Key.Patronymic,
            }).ToObservableCollection();

        //все адреса
        public ObservableCollection<Addresses> SelectAddresses() =>
            (from item in _db.Addresses
                select new
                {
                    item.Id,
                    item.Street,
                    item.House,
                    item.Apartment,
                    DistrictsId = item.District.Id,
                    item.District.PostmenId,
                    DistrictsNumber = item.District.Number
                }).AsEnumerable()
            .Select(item => new Addresses
            {
                Id = item.Id,
                Street = item.Street,
                House = item.House,
                Apartment = item.Apartment,
                District = new Districts { Id = item.DistrictsId, PostmenId = item.PostmenId, Number = item.DistrictsNumber },
                DistrictId=item.DistrictsId
            }).ToObservableCollection();

        #endregion

       

    }//Query



}
