﻿using CourseProject.Context;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace CourseProject
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        // конструктор приложения
        public App()
        {
            InitializeComponent();

            // Формирование окна-заставки выполняется до инициализации компонентов
            SplashScreen splash = new SplashScreen(@"Images\splashScreen.jpg");

            //показ
            splash.Show(false, true);

            // время закрытия окна-заствки - через 0 ч 0 м 5 с после старта
            splash.Close(new TimeSpan(0, 0, 3));

            // выход два варианта
            //ShutdownMode = ShutdownMode.OnExplicitShutdown;  
            ShutdownMode = ShutdownMode.OnLastWindowClose;  

            // Exit - зажигается при завершении приложения 
            Exit += (s, arg)
                 => MessageBox.Show("Приложение завершено", "Информация",
                    MessageBoxButton.OK, MessageBoxImage.Information);

            // перехват необработанных исключений
            DispatcherUnhandledException += (e, arg)
                => MessageBox.Show($"{arg.Exception.Message}\n" +
                                    "------------------------------------------------------\n" +
                                    $"{arg.Exception.StackTrace}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);

        } // App

          // статический метод Main - точка входа приложения 
        [STAThread]  // атрибут запуска приложения в однопоточном окружении
        static void Main()
        {
            App app = new App();
            MainWindow win = new MainWindow();
            app.Run(win);
        }  // Main

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            //создание базы данные протикает тут
            using (PostOfficeContext context = new PostOfficeContext())
            {
                context.Database.Initialize(false);
            }

        } // Application_Startup
    }//App : Application
}
