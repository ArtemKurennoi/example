﻿using CourseProject.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CourseProject.ViewModel.EditViewModel;

namespace CourseProject.View.EditView
{
    /// <summary>
    /// Логика взаимодействия для AddPostman.xaml
    /// </summary>
    public partial class AddPostman : Window
    {
        //для каждого окна своя vm
        public AddPostman(VmAddPostman vm)
        {
            InitializeComponent();
            DataContext = vm;
        }
    }
}
