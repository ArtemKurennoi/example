﻿using CourseProject.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CourseProject.View
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>

    public partial class ManagerView : Window
    {
        //view model
        private PostOffice _postOfficeVm;

        public ManagerView(BaseRoleVm role)
        {
            InitializeComponent();
            _postOfficeVm = new PostOffice(role);
            DataContext = _postOfficeVm;
        }


    }
}
