﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CourseProject.ViewModel.ReportViewModel;

namespace CourseProject.View.ReportView
{
    /// <summary>
    /// Логика взаимодействия для AllPublicationsView.xaml
    /// </summary>
    public partial class AllPublications : Window
    {
        //для каждого окна своя vm
        public AllPublications(VmAllPublications vm)
        {
            InitializeComponent();
            DataContext = vm;
        }

    }
}
