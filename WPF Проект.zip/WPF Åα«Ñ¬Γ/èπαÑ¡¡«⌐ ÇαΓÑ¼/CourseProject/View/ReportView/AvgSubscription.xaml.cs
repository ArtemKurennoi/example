﻿using CourseProject.ViewModel;
using CourseProject.ViewModel.ReportViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CourseProject.View.ReportView
{
    /// <summary>
    /// Логика взаимодействия для AvgSubscription.xaml
    /// </summary>
    public partial class AvgSubscription : Window
    {
        //для каждого окна своя vm
        public AvgSubscription(VmAvgSubscription vm)
        {
            InitializeComponent();
            DataContext = vm;
        }
    }
}
