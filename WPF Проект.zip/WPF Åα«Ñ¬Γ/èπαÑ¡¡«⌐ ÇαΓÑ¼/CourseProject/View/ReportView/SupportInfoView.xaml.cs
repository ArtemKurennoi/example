﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CourseProject.ViewModel;
using CourseProject.ViewModel.ReportViewModel;

namespace CourseProject.View.ReportView
{
    /// <summary>
    /// Логика взаимодействия для SupportInfoView.xaml
    /// </summary>
    public partial class SupportInfoView : Window
    {
        //для каждого окна своя vm
        public SupportInfoView(VmSupportInfoView vm)
        {
            InitializeComponent();
            DataContext = vm;
        }

    }
}
