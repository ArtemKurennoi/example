﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseProject.Model
{
    //Публикации
    public class Publications
    {
        public Publications()
        {
            this.Subscriptions = new HashSet<Subscriptions>();
        }
        public int Id { get; set; }
        public string PublicationIndex { get; set; }
        public string Title { get; set; }
        public double Price { get; set; }
        //актуальность (если актуально - true) по умолчанию
        public bool Relevance { get; set; } = true;

        //навигационные свойства со стороны Один
        //у одного издания может быть любой тип (одно изнадие выбирает любой тип издания)
        public int? PublicationTypeId { get; set; }
        public virtual PublicationTypes PublicationType { get; set; }

        //М
        public virtual ICollection<Subscriptions> Subscriptions { get; set; }
    }
}
