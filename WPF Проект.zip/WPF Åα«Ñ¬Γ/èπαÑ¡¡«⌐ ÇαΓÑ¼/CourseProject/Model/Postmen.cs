﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseProject.Model
{
    //Почтальоны
    public class Postmen
    {
        public Postmen()
        {
            this.Districts = new HashSet<Districts>();
        }
        public int Id { get; set; }
        public string Surname { get; set; }
        public string Name { get; set; }
        public string Patronymic { get; set; }
        //актуальность (если актуально - true) по умолчанию
        public bool Relevance { get; set; } = true;

        //навигационные свойства 
        //Много
        public virtual ICollection<Districts> Districts { get; set; }
    }//Postmen
}
