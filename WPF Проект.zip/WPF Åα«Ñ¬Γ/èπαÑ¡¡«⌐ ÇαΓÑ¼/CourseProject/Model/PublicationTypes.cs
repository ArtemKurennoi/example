﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseProject.Model
{
    //Типы публикаций
    public class PublicationTypes
    {
        public PublicationTypes()
        {
            this.Publications = new HashSet<Publications>();
        }
        public int Id { get; set; }
        public string TypeName { get; set; }

        //навигационные свойства со стороны Mногих
        //у любово типа изданий может быть одно издание (много типов издания может быть выбрана для одной книги)
        public virtual ICollection<Publications> Publications { get; set; }
    }
}
