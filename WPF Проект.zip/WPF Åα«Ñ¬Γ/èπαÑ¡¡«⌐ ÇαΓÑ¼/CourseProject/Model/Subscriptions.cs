﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseProject.Model
{
    //Подписки
    public class Subscriptions
    {
        public int Id { get; set; }
        public DateTime StartDate { get; set; }
        public int Duration { get; set; }

        //навигационные свойства
        //Один
        public int? SubscriberId { get; set; }
        public virtual Subscribers Subscriber { get; set; }
        public int? PublicationId { get; set; }
        public virtual Publications Publication { get; set; }
    }
}
