﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseProject.Model
{
    //Адреса
    public class Addresses
    {
        //TODO: уточнить!
        public Addresses()
        {
            this.Subscribers = new HashSet<Subscribers>();
        }
        public int Id { get; set; }
        public string Street { get; set; }
        public string House { get; set; }
        public int Apartment { get; set; }

        //Один
        public int? DistrictId { get; set; }
        public virtual Districts District { get; set; }

        //много
        public virtual ICollection<Subscribers> Subscribers { get; set; }
    }
}
