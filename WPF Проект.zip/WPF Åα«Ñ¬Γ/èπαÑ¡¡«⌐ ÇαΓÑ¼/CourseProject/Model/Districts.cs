﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseProject.Model
{
    //Районы
    public class Districts
    {
        public Districts()
        {
            this.Addresses = new HashSet<Addresses>();
        }
        public int Id { get; set; }
        public int Number { get; set; }
        public string DistrictName { get; set; }

        //навигационные свойства 
        //Один
        public int? PostmenId { get; set; }
        public virtual Postmen Postmen { get; set; }

        //много
        public virtual ICollection<Addresses> Addresses { get; set; }

    }
}
