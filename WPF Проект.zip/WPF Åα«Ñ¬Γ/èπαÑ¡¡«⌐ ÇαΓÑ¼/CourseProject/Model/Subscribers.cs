﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseProject.Model
{
    //Подписчики
    public class Subscribers
    {
        public Subscribers()
        {
            this.PostOffice = new HashSet<Subscriptions>();
        }
        public int Id { get; set; }
        public string Surname { get; set; }
        public string Name { get; set; }
        public string Patronymic { get; set; }
        //актуальность (если актуально - true) по умолчанию
        public bool Relevance { get; set; } = true;

        //навигационные свойства
        //Один
        public int? AddressId { get; set; }
        public virtual Addresses Address { get; set; }

        //много
        public virtual ICollection<Subscriptions> PostOffice { get; set; }
    }
}
